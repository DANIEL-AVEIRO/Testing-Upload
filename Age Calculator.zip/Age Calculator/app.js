function calculateAge() {
    let resultArea = document.querySelector(".result");

    let inputDate = document.querySelector(".input-date");

    let inputValue = new Date(inputDate.value);
    let currentDate = new Date();

    if(isNaN(inputValue)) {
        resultArea.innerHTML = 'Please enter a valid ...'
    }

    else if(inputValue > currentDate) {
        resultArea.innerHTML = 'Please select a date in the past.'
    }

    else{
        let ageDifference = currentDate - inputValue;

        let mainDate = new Date(ageDifference);

        let years = mainDate.getUTCFullYear() - 1970;
        let months = mainDate.getUTCMonth();
        let days = mainDate.getUTCDate() - 1;

        resultArea.innerHTML = 'Your age is : <span>'+ years +' years</span>, <span>'+ months + ' months</span>, and <span>'+ days +' days</span>.'
    }
}